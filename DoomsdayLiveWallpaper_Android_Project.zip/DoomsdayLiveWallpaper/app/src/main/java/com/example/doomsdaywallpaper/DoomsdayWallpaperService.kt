package com.example.doomsdaywallpaper

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.LinearGradient
import android.graphics.Shader
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import android.os.Handler
import android.os.Looper
import java.time.Duration
import java.time.LocalDateTime
import java.time.temporal.ChronoUnit
import java.util.Locale

class DoomsdayWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = CountdownEngine()

    inner class CountdownEngine : Engine() {
        private val handler = Handler(Looper.getMainLooper())
        private var visible = false
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val target = LocalDateTime.of(2026, 12, 18, 0, 0, 0)

        private val drawRunnable = object : Runnable {
            override fun run() {
                drawFrame()
                if (visible) handler.postDelayed(this, 1000L)
            }
        }

        override fun onVisibilityChanged(isVisible: Boolean) {
            visible = isVisible
            handler.removeCallbacks(drawRunnable)
            if (visible) handler.post(drawRunnable)
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            drawFrame()
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            visible = false
            handler.removeCallbacks(drawRunnable)
            super.onSurfaceDestroyed(holder)
        }

        override fun onDestroy() {
            visible = false
            handler.removeCallbacks(drawRunnable)
            super.onDestroy()
        }

        private fun drawFrame() {
            val holder = surfaceHolder
            var canvas: Canvas? = null
            try {
                canvas = holder.lockCanvas()
                if (canvas != null) render(canvas)
            } catch (_: Exception) {
            } finally {
                if (canvas != null) holder.unlockCanvasAndPost(canvas)
            }
        }

        private fun render(c: Canvas) {
            val w = c.width.toFloat()
            val h = c.height.toFloat()

            paint.shader = LinearGradient(
                0f, 0f, w, h,
                intArrayOf(Color.rgb(11, 74, 68), Color.rgb(6, 35, 24), Color.BLACK),
                floatArrayOf(0f, 0.58f, 1f),
                Shader.TileMode.CLAMP
            )
            c.drawRect(0f, 0f, w, h, paint)
            paint.shader = null

            // Subtle atmospheric glow
            paint.color = Color.argb(35, 0, 255, 190)
            c.drawCircle(w * 0.5f, h * 0.43f, w * 0.42f, paint)

            val now = LocalDateTime.now()
            val finished = !now.isBefore(target)
            val endText = if (finished) "DOOMSDAY IS HERE" else "DOOMSDAY IS COMING"

            paint.color = Color.WHITE
            paint.textAlign = Paint.Align.CENTER
            paint.typeface = android.graphics.Typeface.create("sans-serif-condensed", android.graphics.Typeface.BOLD)
            paint.textSize = w * 0.065f
            c.drawText(endText, w / 2f, h * 0.34f, paint)

            val parts = if (finished) {
                listOf("00", "00", "00", "00", "00")
            } else {
                var cursor = now
                var months = ChronoUnit.MONTHS.between(cursor, target).toInt()
                cursor = cursor.plusMonths(months.toLong())
                while (cursor.isAfter(target) && months > 0) {
                    months--
                    cursor = now.plusMonths(months.toLong())
                }
                val days = ChronoUnit.DAYS.between(cursor, target).toInt()
                cursor = cursor.plusDays(days.toLong())
                val duration = Duration.between(cursor, target)
                val hours = duration.toHours().toInt()
                val minutes = duration.toMinutesPart()
                val seconds = duration.toSecondsPart()
                listOf(
                    String.format(Locale.US, "%02d", months),
                    String.format(Locale.US, "%02d", days),
                    String.format(Locale.US, "%02d", hours),
                    String.format(Locale.US, "%02d", minutes),
                    String.format(Locale.US, "%02d", seconds)
                )
            }

            val labels = listOf("MONTHS", "DAYS", "HOURS", "MINUTES", "SECONDS")
            val centerY = h * 0.49f
            val gap = w * 0.012f
            val cellW = w * 0.184f
            val totalW = cellW * 5 + gap * 4
            var x = (w - totalW) / 2f + cellW / 2f

            for (i in parts.indices) {
                paint.color = Color.WHITE
                paint.textSize = w * 0.075f
                paint.typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD)
                c.drawText(parts[i], x, centerY, paint)

                paint.color = Color.rgb(205, 225, 220)
                paint.textSize = w * 0.023f
                paint.typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD)
                c.drawText(labels[i], x, centerY + w * 0.055f, paint)
                x += cellW + gap
            }

            paint.color = Color.argb(190, 230, 240, 235)
            paint.textSize = w * 0.026f
            paint.typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL)
            c.drawText("18 DECEMBER 2026  •  LOCAL TIME", w / 2f, h * 0.64f, paint)
        }
    }
}
