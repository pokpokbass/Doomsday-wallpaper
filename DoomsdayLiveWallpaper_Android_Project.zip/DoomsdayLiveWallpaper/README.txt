DOOMSDAY COUNTDOWN LIVE WALLPAPER
For Android phones, including Infinix GT 30 Pro.

WHAT THIS PROJECT DOES
- Shows DOOMSDAY IS COMING
- Counts down to 18 December 2026 at 00:00 in the phone's local time
- Updates every second while the live wallpaper is visible
- Uses a dark teal cinematic gradient background

IMPORTANT
This is an Android Studio project, not an installable APK. You need a computer with Android Studio to build the APK.

BUILD AND INSTALL
1. Install Android Studio on a computer.
2. Open this folder in Android Studio.
3. Let Gradle sync. If prompted, install Android SDK 35 and a compatible JDK.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Copy the generated APK from app/build/outputs/apk/debug/ to your phone.
6. Open the APK on your Infinix and allow installation from that source if Android asks.
7. Open "Doomsday Countdown" and tap "Set live wallpaper".
8. Preview it, then choose Set wallpaper.

CHANGE THE DATE
Edit the target line in:
app/src/main/java/com/example/doomsdaywallpaper/DoomsdayWallpaperService.kt
Change LocalDateTime.of(2026, 12, 18, 0, 0, 0) to your desired year, month, day, hour, minute, second.

NOTE
The countdown is a fictional/custom countdown display. It does not predict or indicate a real-world event.
